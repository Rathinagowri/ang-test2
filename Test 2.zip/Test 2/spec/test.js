describe("Check",function(){
	
it("should contain 'a' in array", function () {
    expect(["a", "b", "c"]).toContain("a");
});
})
